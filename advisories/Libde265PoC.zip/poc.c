#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

#include "de265.h"

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <input.bin>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror(argv[1]); return 1; }
    fseek(f, 0, SEEK_END);
    size_t sz = ftell(f);
    rewind(f);
    uint8_t *buf = malloc(sz);
    if (!buf) { fclose(f); return 1; }
    fread(buf, 1, sz, f);
    fclose(f);

    de265_decoder_context *ctx = de265_new_decoder();
    de265_disable_logging();
    de265_set_verbosity(0);
    de265_set_parameter_bool(ctx, DE265_DECODER_PARAM_BOOL_SEI_CHECK_HASH,      0);
    de265_set_parameter_bool(ctx, DE265_DECODER_PARAM_SUPPRESS_FAULTY_PICTURES, 0);
    de265_set_parameter_bool(ctx, DE265_DECODER_PARAM_DISABLE_DEBLOCKING,       0);
    de265_set_parameter_bool(ctx, DE265_DECODER_PARAM_DISABLE_SAO,              0);

    de265_error err = de265_push_data(ctx, buf, (int)sz, 0, NULL);
    if (err != DE265_OK) goto done;
    de265_flush_data(ctx);

    int more = 1;
    while (more) {
        more = 0;
        err = de265_decode(ctx, &more);
        if (err == DE265_ERROR_IMAGE_BUFFER_FULL) { more = 1; continue; }
        if (err != DE265_OK && err != DE265_ERROR_WAITING_FOR_INPUT_DATA) break;
        while (de265_get_next_picture(ctx)) {}
    }

done:
    de265_free_decoder(ctx);
    free(buf);
    return 0;
}
