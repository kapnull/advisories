#define DR_FLAC_IMPLEMENTATION
#include "../dr_flac.h"
#include <stdint.h>
#include <stddef.h>

static void on_meta(void* pUserData, drflac_metadata* pMetadata)
{
    (void)pUserData;
    (void)pMetadata;
}

int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    drflac* pFlac = drflac_open_memory_with_metadata(data, size, on_meta, NULL, NULL);
    if (pFlac)
        drflac_close(pFlac);
    return 0;
}
