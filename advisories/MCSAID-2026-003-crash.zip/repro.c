#include <stdio.h>
#include <stdlib.h>

#define MA_NO_DEVICE_IO
#define MA_NO_THREADING
#define MA_NO_GENERATION
#define MA_IMPLEMENTATION
#include "miniaudio.h"

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <wav_file>\n", argv[0]);
        return 1;
    }

    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror("fopen"); return 1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    rewind(f);
    unsigned char *buf = malloc(sz);
    fread(buf, 1, sz, f);
    fclose(f);

    ma_dr_wav wav;
    ma_dr_wav_init_memory_with_metadata(&wav, buf, (size_t)sz, 0, NULL);
    ma_dr_wav_uninit(&wav);

    free(buf);
    return 0;
}
